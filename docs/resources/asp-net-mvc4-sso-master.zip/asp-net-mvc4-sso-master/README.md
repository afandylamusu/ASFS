# ASP.NET MVC4 .NET 4.5 - SSO with WS-Federation & SAML2

I'm currently working on these samples, will provide a guide soon. Thanks!
